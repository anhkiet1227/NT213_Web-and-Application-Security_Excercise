<?php $data = file_get_contents("flag-mipkBswUppqwXlq9ZydO.php"); echo $data; ?>

